const searchInput = document.getElementById('search-input');
const searchResults = document.getElementById('search-results');
const originalText = searchResults.textContent;
const originalHTML = searchResults.innerHTML;

searchInput.addEventListener('input', () => {
  const regex = new RegExp(searchInput.value, 'gi');
  const matches = originalText.match(regex);

  if (searchInput.value === '') {
    searchResults.innerHTML = originalHTML;
  } else if (matches) {
    searchResults.innerHTML = originalHTML.replace(
      regex,
      match => `<span class="highlight">${match}</span>`
    );
  } else {
    searchResults.innerHTML = originalHTML;
  }
});